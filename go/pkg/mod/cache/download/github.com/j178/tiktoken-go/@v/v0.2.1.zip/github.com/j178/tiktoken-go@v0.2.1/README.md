# tiktoken-go

A Go binding for [tiktoken-rs](https://github.com/zurawiki/tiktoken-rs), for tokenizing text with OpenAI models using tiktoken.
