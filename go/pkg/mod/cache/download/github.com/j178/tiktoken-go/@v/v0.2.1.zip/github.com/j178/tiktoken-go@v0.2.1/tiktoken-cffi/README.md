# CFFI for tiktoken-cffi

See: https://github.com/mediremi/rust-plus-golang
