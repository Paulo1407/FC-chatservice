package ast

type FetchDirection uint

func (n *FetchDirection) Pos() int {
	return 0
}
