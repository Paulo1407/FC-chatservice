package ast

type LockClauseStrength uint

func (n *LockClauseStrength) Pos() int {
	return 0
}
