package ast

type AlterSubscriptionType uint

func (n *AlterSubscriptionType) Pos() int {
	return 0
}
