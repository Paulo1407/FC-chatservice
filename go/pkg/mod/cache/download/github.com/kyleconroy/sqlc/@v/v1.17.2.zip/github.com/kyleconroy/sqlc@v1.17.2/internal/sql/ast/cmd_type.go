package ast

type CmdType uint

func (n *CmdType) Pos() int {
	return 0
}
