This database schema and query selection is taken from the
[SQLBoiler](https://github.com/volatiletech/sqlboiler#features--examples)
README.
