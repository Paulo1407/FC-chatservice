CREATE TABLE authors (
          id   integer    PRIMARY KEY AUTOINCREMENT,
          name text   NOT NULL,
          bio  text
);
