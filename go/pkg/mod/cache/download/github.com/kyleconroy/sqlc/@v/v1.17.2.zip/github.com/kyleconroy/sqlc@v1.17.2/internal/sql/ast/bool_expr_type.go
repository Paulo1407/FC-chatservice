package ast

type BoolExprType uint

func (n *BoolExprType) Pos() int {
	return 0
}
