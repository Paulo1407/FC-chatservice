package ast

type GrantObjectType uint

func (n *GrantObjectType) Pos() int {
	return 0
}
