export default function Pagina1(){
    return (
        <div>
            <h1>Pagina 1</h1>
            <p>Esta es la pagina 1</p>
        </div>
    )
}